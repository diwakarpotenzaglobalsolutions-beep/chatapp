import 'package:chatapp/presentation/blocs/chat_request/chat_request_bloc.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'firebase_options.dart';
import 'injection/injection_container.dart' as sl;
import 'core/services/notification_service.dart';
import 'routes/router.dart';
import 'core/constants/theme.dart';

// Blocs
import 'presentation/blocs/auth/auth_bloc.dart';
import 'presentation/blocs/home/home_bloc.dart';
import 'presentation/blocs/notification/notification_bloc.dart';
import 'presentation/blocs/settings/settings_bloc.dart';
import 'presentation/blocs/chat_list/chat_list_bloc.dart';
import 'presentation/blocs/search/search_bloc.dart';
import 'presentation/blocs/chat/chat_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // 2. Initialize Dependency Injection
  await sl.init();

  // 3. Initialize Notification Service
  await sl.sl<NotificationService>().initialize();


  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => sl.sl<AuthBloc>()..add(AppStarted())),
        BlocProvider(create: (context) => sl.sl<HomeBloc>()),
        BlocProvider(create: (context) => sl.sl<SettingsBloc>()..add(LoadSettings())),
        BlocProvider(create: (context) => sl.sl<NotificationBloc>()..add(InitializeNotifications())),
        BlocProvider(create: (context) => sl.sl<ChatListBloc>()),
        BlocProvider(create: (context) => sl.sl<SearchBloc>()),
        BlocProvider(create: (context) => sl.sl<ChatBloc>()),
        BlocProvider(create: (context) => sl.sl<ChatRequestBloc>()),
      ],
      child: BlocListener<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is Authenticated) {
            context.read<NotificationBloc>().add(SaveFcmToken(state.user.uid));
          }
        },
        child: BlocBuilder<SettingsBloc, SettingsState>(
          builder: (context, state) {
            bool isDarkMode = true;
            if (state is SettingsLoaded) {
              isDarkMode = state.isDarkMode;
            }

            return MaterialApp.router(
              title: 'Aether Chat',
              debugShowCheckedModeBanner: false,
              theme: AppTheme.lightTheme,
              darkTheme: AppTheme.darkTheme,
              themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
              routerConfig: AppRoutes.router,
            );
          },
        ),
      ),
    );
  }
}
