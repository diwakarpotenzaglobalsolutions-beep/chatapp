enum ChatRoomType { direct, group }
