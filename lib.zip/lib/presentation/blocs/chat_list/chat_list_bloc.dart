import 'dart:async';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../domain/entities/chat_room_entity.dart';
import '../../../domain/usecases/chat_usecases.dart';

// Events
abstract class ChatListEvent extends Equatable {
  const ChatListEvent();
  @override
  List<Object?> get props => [];
}

class SubscribeToChatRooms extends ChatListEvent {
  final String uid;
  const SubscribeToChatRooms(this.uid);
  @override
  List<Object?> get props => [uid];
}

class ChatRoomsUpdated extends ChatListEvent {
  final List<ChatRoomEntity> rooms;
  const ChatRoomsUpdated(this.rooms);
  @override
  List<Object?> get props => [rooms];
}

// States
abstract class ChatListState extends Equatable {
  const ChatListState();
  @override
  List<Object?> get props => [];
}

class ChatListInitial extends ChatListState {}

class ChatListLoading extends ChatListState {}

class ChatListLoaded extends ChatListState {
  final List<ChatRoomEntity> rooms;
  const ChatListLoaded(this.rooms);
  @override
  List<Object?> get props => [rooms];
}

class ChatListFailure extends ChatListState {
  final String error;
  const ChatListFailure(this.error);
  @override
  List<Object?> get props => [error];
}

// Bloc
class ChatListBloc extends Bloc<ChatListEvent, ChatListState> {
  final GetChatRoomsUseCase _getChatRoomsUseCase;
  StreamSubscription<List<ChatRoomEntity>>? _roomsSubscription;

  ChatListBloc({required GetChatRoomsUseCase getChatRoomsUseCase})
      : _getChatRoomsUseCase = getChatRoomsUseCase,
        super(ChatListInitial()) {
    on<SubscribeToChatRooms>(_onSubscribeToChatRooms);
    on<ChatRoomsUpdated>(_onChatRoomsUpdated);
  }

  void _onSubscribeToChatRooms(SubscribeToChatRooms event, Emitter<ChatListState> emit) {
    emit(ChatListLoading());
    _roomsSubscription?.cancel();
    _roomsSubscription = _getChatRoomsUseCase(event.uid).listen(
      (rooms) {
        add(ChatRoomsUpdated(rooms));
      },
      onError: (e) {
        emit(ChatListFailure(e.toString()));
      },
    );
  }

  void _onChatRoomsUpdated(ChatRoomsUpdated event, Emitter<ChatListState> emit) {
    emit(ChatListLoaded(event.rooms));
  }

  @override
  Future<void> close() {
    _roomsSubscription?.cancel();
    return super.close();
  }
}
