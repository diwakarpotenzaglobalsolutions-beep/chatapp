import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../domain/usecases/auth_usecases.dart';

// Events
abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override
  List<Object?> get props => [];
}

class ToggleDarkMode extends SettingsEvent {
  final bool isDarkMode;
  const ToggleDarkMode(this.isDarkMode);
  @override
  List<Object?> get props => [isDarkMode];
}

class LoadSettings extends SettingsEvent {}

class LogoutRequestedSettings extends SettingsEvent {}

// States
abstract class SettingsState extends Equatable {
  const SettingsState();
  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final bool isDarkMode;
  const SettingsLoaded({required this.isDarkMode});
  @override
  List<Object?> get props => [isDarkMode];
}

class SettingsLogoutSuccess extends SettingsState {}

// Bloc
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  final SignOutUseCase _signOutUseCase;
  bool _isDarkMode = true; // default dark mode first

  SettingsBloc({required SignOutUseCase signOutUseCase})
      : _signOutUseCase = signOutUseCase,
        super(SettingsInitial()) {
    on<LoadSettings>((event, emit) {
      emit(SettingsLoaded(isDarkMode: _isDarkMode));
    });
    on<ToggleDarkMode>((event, emit) {
      _isDarkMode = event.isDarkMode;
      emit(SettingsLoaded(isDarkMode: _isDarkMode));
    });
    on<LogoutRequestedSettings>((event, emit) async {
      try {
        await _signOutUseCase();
        emit(SettingsLogoutSuccess());
      } catch (_) {}
    });
  }
}
