import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../domain/entities/user_entity.dart';
import '../../../domain/usecases/auth_usecases.dart';
import '../../../domain/usecases/chat_usecases.dart';

// Events
abstract class HomeEvent extends Equatable {
  const HomeEvent();
  @override
  List<Object?> get props => [];
}

class LoadHome extends HomeEvent {}

class UpdatePresence extends HomeEvent {
  final bool isOnline;
  const UpdatePresence(this.isOnline);
  @override
  List<Object?> get props => [isOnline];
}

// States
abstract class HomeState extends Equatable {
  const HomeState();
  @override
  List<Object?> get props => [];
}

class HomeInitial extends HomeState {}

class HomeLoading extends HomeState {}

class HomeLoaded extends HomeState {
  final UserEntity currentUser;
  const HomeLoaded(this.currentUser);
  @override
  List<Object?> get props => [currentUser];
}

class HomeFailure extends HomeState {
  final String error;
  const HomeFailure(this.error);
  @override
  List<Object?> get props => [error];
}

// Bloc
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final GetCurrentUserUseCase _getCurrentUserUseCase;
  final UpdateUserPresenceUseCase _updateUserPresenceUseCase;

  HomeBloc({
    required this._getCurrentUserUseCase,
    required this._updateUserPresenceUseCase,
  })  : super(HomeInitial()) {
    on<LoadHome>(_onLoadHome);
    on<UpdatePresence>(_onUpdatePresence);
  }

  Future<void> _onLoadHome(LoadHome event, Emitter<HomeState> emit) async {
    emit(HomeLoading());
    try {
      final user = await _getCurrentUserUseCase();
      if (user != null) {
        await _updateUserPresenceUseCase(user.uid, true);
        emit(HomeLoaded(user));
      } else {
        emit(const HomeFailure('User not logged in.'));
      }
    } catch (e) {
      emit(HomeFailure(e.toString()));
    }
  }

  Future<void> _onUpdatePresence(UpdatePresence event, Emitter<HomeState> emit) async {
    final state = this.state;
    if (state is HomeLoaded) {
      try {
        await _updateUserPresenceUseCase(state.currentUser.uid, event.isOnline);
      } catch (_) {}
    }
  }
}
