import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/theme.dart';
import '../../domain/entities/user_entity.dart';
import '../../injection/injection_container.dart';
import '../../routes/router.dart';
import '../blocs/chat/chat_bloc.dart';
import '../blocs/home/home_bloc.dart';
import '../blocs/profile/profile_bloc.dart';

class ProfileScreen extends StatelessWidget {
  final String uid;
  const ProfileScreen({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    final homeState = context.read<HomeBloc>().state;
    final currentUserId = homeState is HomeLoaded ? homeState.currentUser.uid : '';
    final isMe = uid == currentUserId;

    return BlocProvider(
      create: (context) => sl<ProfileBloc>()..add(LoadProfile(uid)),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Profile'),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: AppColors.darkBackgroundGradient,
          ),
          child: BlocBuilder<ProfileBloc, ProfileState>(
            builder: (context, state) {
              if (state is ProfileLoading) {
                return const Center(child: CircularProgressIndicator(color: AppColors.primary));
              }
              if (state is ProfileLoaded) {
                final user = state.user;
                return SingleChildScrollView(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Avatar
                      Center(
                        child: CircleAvatar(
                          radius: 60,
                          backgroundColor: AppColors.surfaceLight,
                          backgroundImage: user.profilePicture.isNotEmpty
                              ? CachedNetworkImageProvider(user.profilePicture)
                              : null,
                          child: user.profilePicture.isEmpty
                              ? const Icon(Icons.person, size: 60, color: Colors.white)
                              : null,
                        ),
                      ),
                      const SizedBox(height: 16),

                      // Name
                      Text(
                        user.fullName,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      
                      // Username
                      Text(
                        '@${user.username}',
                        style: const TextStyle(fontSize: 16, color: AppColors.secondary, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 12),

                      // Bio Card
                      Card(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              const Text('About', style: TextStyle(color: AppColors.textMuted, fontSize: 13, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              Text(
                                user.bio.isNotEmpty ? user.bio : 'No bio set yet.',
                                style: const TextStyle(fontSize: 15, color: AppColors.textPrimary),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Meta details Card
                      Card(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Column(
                            children: [
                              _buildProfileRow(Icons.email_outlined, 'Email', user.email),
                              const Divider(color: Colors.white12, height: 1),
                              _buildProfileRow(Icons.phone_outlined, 'Phone', user.phoneNumber.isNotEmpty ? user.phoneNumber : 'Not set'),
                              const Divider(color: Colors.white12, height: 1),
                              _buildProfileRow(Icons.cake_outlined, 'Date of Birth', user.dateOfBirth.isNotEmpty ? user.dateOfBirth : 'Not set'),
                              const Divider(color: Colors.white12, height: 1),
                              _buildProfileRow(Icons.face_outlined, 'Gender', user.gender.isNotEmpty ? user.gender : 'Not set'),
                              const Divider(color: Colors.white12, height: 1),
                              _buildProfileRow(Icons.location_on_outlined, 'Location', _formatLocation(user.city, user.country)),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Action Button
                      if (isMe)
                        ElevatedButton.icon(
                          onPressed: () => context.push(AppRoutes.editProfile),
                          icon: const Icon(Icons.edit),
                          label: const Text('EDIT PROFILE'),
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size.fromHeight(50),
                          ),
                        )
                      else
                        BlocListener<ChatBloc, ChatState>(
                          listener: (context, chatState) {
                            if (chatState is ChatRoomLoaded) {
                              context.push(
                                '${AppRoutes.chat}/${chatState.roomId}',
                                extra: {
                                  'peerId': user.uid,
                                  'peerName': user.fullName,
                                  'peerImage': user.profilePicture,
                                },
                              );
                            }
                          },
                          child: ElevatedButton.icon(
                            onPressed: () {
                              if (currentUserId.isNotEmpty) {
                                context.read<ChatBloc>().add(
                                  EnterChatRoom(
                                    uid1: currentUserId,
                                    uid2: user.uid,
                                  ),
                                );
                              }
                            },
                            icon: const Icon(Icons.chat_bubble_outline),
                            label: const Text('MESSAGE'),
                            style: ElevatedButton.styleFrom(
                              minimumSize: const Size.fromHeight(50),
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              }
              if (state is ProfileFailure) {
                return Center(child: Text('Failed to load profile: ${state.error}'));
              }
              return Container();
            },
          ),
        ),
      ),
    );
  }

  Widget _buildProfileRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 22),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontSize: 15, color: AppColors.textPrimary)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatLocation(String city, String country) {
    if (city.isEmpty && country.isEmpty) return 'Not set';
    if (city.isEmpty) return country;
    if (country.isEmpty) return city;
    return '$city, $country';
  }
}
