import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as p;

import '../../core/constants/theme.dart';
import '../../domain/entities/message_entity.dart';
import '../../routes/router.dart';
import '../blocs/audio/audio_bloc.dart';
import '../blocs/auth/auth_bloc.dart';
import '../blocs/location/location_bloc.dart';
import '../blocs/message/message_bloc.dart';
import '../blocs/search/search_bloc.dart';
import '../blocs/typing/typing_bloc.dart';
import '../blocs/upload/upload_bloc.dart';

class GroupChatScreen extends StatefulWidget {
  final String roomId;
  final String groupName;
  final String groupImage;

  const GroupChatScreen({
    super.key,
    required this.roomId,
    required this.groupName,
    required this.groupImage,
  });

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final _searchController = TextEditingController();
  final _picker = ImagePicker();
  final _uuid = const Uuid();

  Timer? _typingDebounce;
  bool _isWriting = false;
  bool _showSearch = false;
  String _currentUserName = '';

  @override
  void initState() {
    super.initState();
    final authState = context.read<AuthBloc>().state;
    if (authState is Authenticated) {
      _currentUserName = authState.user.fullName;
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _searchController.dispose();
    _typingDebounce?.cancel();
    super.dispose();
  }

  void _onTextChanged(String text, String currentUserId) {
    if (!_isWriting && text.isNotEmpty) {
      _isWriting = true;
      context.read<TypingBloc>().add(
            UpdateTypingRequest(roomId: widget.roomId, uid: currentUserId, isTyping: true),
          );
    } else if (_isWriting && text.isEmpty) {
      _isWriting = false;
      context.read<TypingBloc>().add(
            UpdateTypingRequest(roomId: widget.roomId, uid: currentUserId, isTyping: false),
          );
    }

    _typingDebounce?.cancel();
    _typingDebounce = Timer(const Duration(seconds: 3), () {
      if (_isWriting) {
        _isWriting = false;
        context.read<TypingBloc>().add(
              UpdateTypingRequest(roomId: widget.roomId, uid: currentUserId, isTyping: false),
            );
      }
    });
  }

  void _sendMessage(
    String text,
    MessageType type,
    String currentUserId, {
    String? mediaUrl,
    Duration? duration,
    double? lat,
    double? lng,
    String? fileName,
    String? fileSize,
  }) {
    if (text.trim().isEmpty && mediaUrl == null) return;

    final message = MessageEntity(
      messageId: _uuid.v4(),
      senderId: currentUserId,
      senderName: _currentUserName,
      receiverId: '',
      content: text,
      type: type,
      timestamp: DateTime.now(),
      status: MessageStatus.delivered,
      mediaUrl: mediaUrl,
      duration: duration,
      latitude: lat,
      longitude: lng,
      fileName: fileName,
      fileSize: fileSize,
    );

    context.read<MessageBloc>().add(
          SendMessageRequested(roomId: widget.roomId, message: message),
        );

    _messageController.clear();
    if (_isWriting) {
      _isWriting = false;
      context.read<TypingBloc>().add(
            UpdateTypingRequest(roomId: widget.roomId, uid: currentUserId, isTyping: false),
          );
    }

    Timer(const Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _pickImage(String currentUserId) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.image, currentUserId);
    }
  }

  Future<void> _captureImage(String currentUserId) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.image, currentUserId);
    }
  }

  Future<void> _pickVideo(String currentUserId) async {
    final pickedFile = await _picker.pickVideo(source: ImageSource.gallery);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.video, currentUserId);
    }
  }

  void _uploadAndSendFile(
    String path,
    MessageType type,
    String currentUserId, {
    String? customFileName,
    String? fileSize,
  }) {
    String folder = 'chat_documents';
    if (type == MessageType.image) folder = 'chat_images';
    if (type == MessageType.video) folder = 'chat_videos';
    if (type == MessageType.voice) folder = 'chat_audio';

    context.read<UploadBloc>().add(UploadFileRequested(filePath: path, folder: folder));

    late StreamSubscription uploadSubscription;
    uploadSubscription = context.read<UploadBloc>().stream.listen((state) {
      if (state is UploadSuccess) {
        _sendMessage(
          customFileName ?? p.basename(path),
          type,
          currentUserId,
          mediaUrl: state.downloadUrl,
          fileName: customFileName ?? p.basename(path),
          fileSize: fileSize,
        );
        uploadSubscription.cancel();
      } else if (state is UploadFailure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: ${state.error}'), backgroundColor: AppColors.error),
        );
        uploadSubscription.cancel();
      }
    });
  }

  void _sendLocation(String currentUserId) {
    context.read<LocationBloc>().add(FetchCurrentLocationRequested());

    late StreamSubscription locationSubscription;
    locationSubscription = context.read<LocationBloc>().stream.listen((state) {
      if (state is LocationSuccess) {
        _sendMessage(
          'Location shared',
          MessageType.location,
          currentUserId,
          lat: state.latitude,
          lng: state.longitude,
        );
        locationSubscription.cancel();
      } else if (state is LocationFailure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Location failed: ${state.error}'), backgroundColor: AppColors.error),
        );
        locationSubscription.cancel();
      }
    });
  }

  void _showAttachmentOptions(BuildContext context, String currentUserId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _AttachmentItem(
                  icon: Icons.image_rounded,
                  label: 'Gallery',
                  color: Colors.purple,
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.camera_alt_rounded,
                  label: 'Camera',
                  color: Colors.pink,
                  onTap: () {
                    Navigator.pop(context);
                    _captureImage(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.videocam_rounded,
                  label: 'Video',
                  color: Colors.orange,
                  onTap: () {
                    Navigator.pop(context);
                    _pickVideo(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.location_on_rounded,
                  label: 'Location',
                  color: Colors.green,
                  onTap: () {
                    Navigator.pop(context);
                    _sendLocation(currentUserId);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showReadByDialog(MessageEntity message) {
    if (message.readBy.isEmpty) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Seen by'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: message.readBy.entries.map((e) {
            final time = DateTime.tryParse(e.value);
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(
                '${e.key == message.senderId ? 'You (sender)' : e.key}: ${time != null ? DateFormat('HH:mm').format(time) : e.value}',
                style: const TextStyle(fontSize: 13),
              ),
            );
          }).toList(),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.read<AuthBloc>().state;
    final currentUserId = authState is Authenticated ? authState.user.uid : '';

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
        title: GestureDetector(
          onTap: () => context.push('${AppRoutes.groupInfo}/${widget.roomId}'),
          child: Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: AppColors.surfaceLight,
                backgroundImage: widget.groupImage.isNotEmpty
                    ? CachedNetworkImageProvider(widget.groupImage)
                    : null,
                child: widget.groupImage.isEmpty
                    ? const Icon(Icons.groups, color: Colors.white, size: 20)
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.groupName,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Text(
                      'Tap for group info',
                      style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(_showSearch ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                _showSearch = !_showSearch;
                if (!_showSearch) {
                  _searchController.clear();
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => context.push('${AppRoutes.groupInfo}/${widget.roomId}'),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.darkBackgroundGradient),
        child: Column(
          children: [
            if (_showSearch)
              Padding(
                padding: const EdgeInsets.all(8),
                child: TextField(
                  controller: _searchController,
                  onChanged: (q) {
                    context.read<SearchBloc>().add(
                          SearchMessagesRequested(roomId: widget.roomId, query: q),
                        );
                  },
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'Search messages in this group...',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ),
            if (_showSearch)
              BlocBuilder<SearchBloc, SearchState>(
                builder: (context, state) {
                  if (state is SearchMessagesSuccess && state.messages.isNotEmpty) {
                    return SizedBox(
                      height: 120,
                      child: ListView.builder(
                        itemCount: state.messages.length,
                        itemBuilder: (_, i) {
                          final msg = state.messages[i];
                          return ListTile(
                            dense: true,
                            title: Text(
                              msg.content,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              '${msg.senderName.isNotEmpty ? msg.senderName : msg.senderId} • ${DateFormat('HH:mm').format(msg.timestamp)}',
                              style: const TextStyle(fontSize: 11),
                            ),
                          );
                        },
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            BlocBuilder<UploadBloc, UploadState>(
              builder: (context, state) {
                if (state is UploadProgress) {
                  return LinearProgressIndicator(
                    value: state.progress,
                    backgroundColor: Colors.white12,
                    valueColor: const AlwaysStoppedAnimation<Color>(AppColors.secondary),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
            Expanded(
              child: BlocBuilder<MessageBloc, MessageState>(
                builder: (context, state) {
                  if (state is MessageLoading) {
                    return const Center(child: CircularProgressIndicator(color: AppColors.primary));
                  }
                  if (state is MessagesLoaded) {
                    final messages = state.messages;
                    if (messages.isEmpty) {
                      return Center(
                        child: Text(
                          'Start the conversation in ${widget.groupName} 👋',
                          style: const TextStyle(color: AppColors.textMuted),
                        ),
                      );
                    }

                    Timer(const Duration(milliseconds: 100), () {
                      if (_scrollController.hasClients) {
                        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
                      }
                    });

                    return ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      itemCount: messages.length,
                      itemBuilder: (context, index) {
                        final message = messages[index];
                        final isMe = message.senderId == currentUserId;
                        return _GroupMessageBubble(
                          message: message,
                          isMe: isMe,
                          onReadByTap: isMe ? () => _showReadByDialog(message) : null,
                        );
                      },
                    );
                  }
                  if (state is MessageFailure) {
                    return Center(child: Text('Error: ${state.error}'));
                  }
                  return Container();
                },
              ),
            ),
            _buildTypingIndicator(currentUserId),
            _buildInputBar(context, currentUserId),
          ],
        ),
      ),
    );
  }

  Widget _buildTypingIndicator(String currentUserId) {
    return BlocBuilder<TypingBloc, TypingState>(
      builder: (context, state) {
        if (state is TypingUpdated) {
          final typingUsers = state.typingMap.entries
              .where((e) => e.value && e.key != currentUserId)
              .map((e) => e.key)
              .toList();
          if (typingUsers.isNotEmpty) {
            return Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Text(
                  '${typingUsers.length} member(s) typing...',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
            );
          }
        }
        return const SizedBox.shrink();
      },
    );
  }

  Widget _buildInputBar(BuildContext context, String currentUserId) {
    return BlocBuilder<AudioBloc, AudioState>(
      builder: (context, audioState) {
        final isRecording = audioState is AudioRecordingInProgress;

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: const Color(0x1AFFFFFF)),
                    ),
                    child: Row(
                      children: [
                        if (!isRecording)
                          IconButton(
                            icon: const Icon(Icons.attach_file_rounded, color: AppColors.textSecondary),
                            onPressed: () => _showAttachmentOptions(context, currentUserId),
                          ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: isRecording
                                ? const _VoiceRecordingPanel()
                                : TextFormField(
                                    controller: _messageController,
                                    onChanged: (text) => _onTextChanged(text, currentUserId),
                                    style: const TextStyle(color: Colors.white),
                                    decoration: const InputDecoration(
                                      hintText: 'Type a message...',
                                      border: InputBorder.none,
                                      enabledBorder: InputBorder.none,
                                      focusedBorder: InputBorder.none,
                                      contentPadding: EdgeInsets.zero,
                                    ),
                                  ),
                          ),
                        ),
                        if (!isRecording)
                          IconButton(
                            icon: const Icon(Icons.mic_none_rounded, color: AppColors.textSecondary),
                            onPressed: () {
                              context.read<AudioBloc>().add(StartRecordingRequested());
                            },
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () async {
                    if (isRecording) {
                      context.read<AudioBloc>().add(StopRecordingRequested());
                      late StreamSubscription audioSub;
                      audioSub = context.read<AudioBloc>().stream.listen((state) {
                        if (state is AudioRecordingSuccess) {
                          _uploadAndSendFile(state.filePath, MessageType.voice, currentUserId);
                          audioSub.cancel();
                        }
                      });
                    } else {
                      _sendMessage(_messageController.text, MessageType.text, currentUserId);
                    }
                  },
                  child: CircleAvatar(
                    radius: 24,
                    backgroundColor: AppColors.primary,
                    child: Icon(
                      isRecording ? Icons.stop_rounded : Icons.send_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _GroupMessageBubble extends StatelessWidget {
  final MessageEntity message;
  final bool isMe;
  final VoidCallback? onReadByTap;

  const _GroupMessageBubble({
    required this.message,
    required this.isMe,
    this.onReadByTap,
  });

  @override
  Widget build(BuildContext context) {
    final alignment = isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = isMe ? AppColors.primary : AppColors.surface;
    final textStyle = TextStyle(
      color: isMe ? Colors.white : AppColors.textPrimary,
      fontSize: 15,
    );

    return Column(
      crossAxisAlignment: alignment,
      children: [
        if (!isMe && message.senderName.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 2),
            child: Text(
              message.senderName,
              style: const TextStyle(
                color: AppColors.secondary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        GestureDetector(
          onLongPress: onReadByTap,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bubbleColor,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: isMe ? const Radius.circular(16) : const Radius.circular(0),
                bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(16),
              ),
              border: Border.all(color: const Color(0x1AFFFFFF), width: 0.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildMessageContent(context, textStyle),
                const SizedBox(height: 6),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      DateFormat('HH:mm').format(message.timestamp),
                      style: TextStyle(
                        color: isMe ? Colors.white70 : AppColors.textMuted,
                        fontSize: 10,
                      ),
                    ),
                    if (isMe) ...[
                      const SizedBox(width: 4),
                      GestureDetector(
                        onTap: onReadByTap,
                        child: _buildReceiptTick(message.status),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMessageContent(BuildContext context, TextStyle defaultStyle) {
    switch (message.type) {
      case MessageType.text:
        return Text(message.content, style: defaultStyle);
      case MessageType.image:
        return GestureDetector(
          onTap: () {
            context.push(
              AppRoutes.imageViewer,
              extra: {'url': message.mediaUrl ?? '', 'tag': message.messageId},
            );
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: CachedNetworkImage(
              imageUrl: message.mediaUrl ?? '',
              placeholder: (_, __) => const SizedBox(
                height: 150,
                child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
              ),
              errorWidget: (_, __, ___) => const Icon(Icons.error, color: AppColors.error),
              fit: BoxFit.cover,
            ),
          ),
        );
      case MessageType.video:
        return GestureDetector(
          onTap: () => context.push(AppRoutes.videoPlayer, extra: {'url': message.mediaUrl ?? ''}),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 150,
                width: 200,
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.videocam, size: 40, color: Colors.white54),
              ),
              const CircleAvatar(
                radius: 24,
                backgroundColor: Colors.black54,
                child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 32),
              ),
            ],
          ),
        );
      case MessageType.voice:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.mic, color: Colors.white70),
            const SizedBox(width: 8),
            Text('Voice message', style: defaultStyle),
          ],
        );
      case MessageType.file:
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.insert_drive_file_rounded, color: Colors.amber, size: 36),
            const SizedBox(width: 8),
            Text(message.fileName ?? 'Document', style: defaultStyle),
          ],
        );
      case MessageType.location:
        return Row(
          children: [
            const Icon(Icons.location_on, color: Colors.redAccent, size: 16),
            const SizedBox(width: 4),
            Text('Shared Location', style: defaultStyle.copyWith(fontSize: 13)),
          ],
        );
    }
  }

  Widget _buildReceiptTick(MessageStatus status) {
    switch (status) {
      case MessageStatus.sent:
        return const Icon(Icons.check, size: 14, color: Colors.white70);
      case MessageStatus.delivered:
        return const Icon(Icons.done_all, size: 14, color: Colors.white70);
      case MessageStatus.seen:
        return const Icon(Icons.done_all, size: 14, color: AppColors.secondary);
    }
  }
}

class _VoiceRecordingPanel extends StatefulWidget {
  const _VoiceRecordingPanel();
  @override
  State<_VoiceRecordingPanel> createState() => _VoiceRecordingPanelState();
}

class _VoiceRecordingPanelState extends State<_VoiceRecordingPanel> {
  int _seconds = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => _seconds++));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mins = _seconds ~/ 60;
    final secs = _seconds % 60;
    return Row(
      children: [
        const Icon(Icons.fiber_manual_record, color: AppColors.error, size: 14),
        const SizedBox(width: 8),
        Text(
          'Recording... ${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}',
          style: const TextStyle(color: AppColors.textPrimary),
        ),
      ],
    );
  }
}

class _AttachmentItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _AttachmentItem({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: color.withOpacity(0.15),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }
}
