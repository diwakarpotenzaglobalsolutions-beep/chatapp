import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
//import 'package:file_picker/file_picker.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as p;

import '../../core/constants/theme.dart';
import '../../core/services/location_service.dart';
import '../../domain/entities/chat_request_entity.dart';
import '../../domain/entities/message_entity.dart';
import '../../injection/injection_container.dart';
import '../../routes/router.dart';
import '../blocs/audio/audio_bloc.dart';
import '../blocs/auth/auth_bloc.dart';
import '../blocs/chat_request/chat_request_bloc.dart';
import '../blocs/location/location_bloc.dart';
import '../blocs/message/message_bloc.dart';
import '../blocs/presence/presence_bloc.dart';
import '../blocs/typing/typing_bloc.dart';
import '../blocs/upload/upload_bloc.dart';

class ChatScreen extends StatefulWidget {
  final String roomId;
  final String peerId;
  final String peerName;
  final String peerImage;

  const ChatScreen({
    super.key,
    required this.roomId,
    required this.peerId,
    required this.peerName,
    required this.peerImage,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final _picker = ImagePicker();
  final _uuid = const Uuid();

  Timer? _typingDebounce;
  bool _isWriting = false;

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _typingDebounce?.cancel();
    super.dispose();
  }

  void _onTextChanged(String text, String currentUserId) {
    if (!_isWriting && text.isNotEmpty) {
      _isWriting = true;
      context.read<TypingBloc>().add(
        UpdateTypingRequest(
          roomId: widget.roomId,
          uid: currentUserId,
          isTyping: true,
        ),
      );
    } else if (_isWriting && text.isEmpty) {
      _isWriting = false;
      context.read<TypingBloc>().add(
        UpdateTypingRequest(
          roomId: widget.roomId,
          uid: currentUserId,
          isTyping: false,
        ),
      );
    }

    _typingDebounce?.cancel();
    _typingDebounce = Timer(const Duration(seconds: 3), () {
      if (_isWriting) {
        _isWriting = false;
        context.read<TypingBloc>().add(
          UpdateTypingRequest(
            roomId: widget.roomId,
            uid: currentUserId,
            isTyping: false,
          ),
        );
      }
    });
  }

  void _sendMessage(
      String text,
      MessageType type,
      String currentUserId, {
        String? mediaUrl,
        Duration? duration,
        double? lat,
        double? lng,
        String? fileName,
        String? fileSize,
      }) {
    if (text.trim().isEmpty && mediaUrl == null) return;

    final reqState = context.read<ChatRequestBloc>().state;
    if (!_canSendMessages(reqState)) return;

    final message = MessageEntity(
      messageId: _uuid.v4(),
      senderId: currentUserId,
      receiverId: widget.peerId,
      content: text,
      type: type,
      timestamp: DateTime.now(),
      status: MessageStatus.delivered,
      mediaUrl: mediaUrl,
      duration: duration,
      latitude: lat,
      longitude: lng,
      fileName: fileName,
      fileSize: fileSize,
    );

    context.read<MessageBloc>().add(
      SendMessageRequested(
        roomId: widget.roomId,
        message: message,
      ),
    );

    _messageController.clear();
    if (_isWriting) {
      _isWriting = false;
      context.read<TypingBloc>().add(
        UpdateTypingRequest(
          roomId: widget.roomId,
          uid: currentUserId,
          isTyping: false,
        ),
      );
    }

    Timer(const Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _pickImage(String currentUserId) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.image, currentUserId);
    }
  }

  Future<void> _captureImage(String currentUserId) async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.image, currentUserId);
    }
  }

  Future<void> _pickVideo(String currentUserId) async {
    final pickedFile = await _picker.pickVideo(source: ImageSource.gallery);
    if (pickedFile != null) {
      _uploadAndSendFile(pickedFile.path, MessageType.video, currentUserId);
    }
  }

  void _uploadAndSendFile(
      String path,
      MessageType type,
      String currentUserId, {
        String? customFileName,
        String? fileSize,
      }) {
    String folder = 'chat_documents';
    if (type == MessageType.image) folder = 'chat_images';
    if (type == MessageType.video) folder = 'chat_videos';
    if (type == MessageType.voice) folder = 'chat_audio';

    context.read<UploadBloc>().add(
      UploadFileRequested(filePath: path, folder: folder),
    );

    late StreamSubscription uploadSubscription;
    uploadSubscription = context.read<UploadBloc>().stream.listen((state) {
      if (state is UploadSuccess) {
        _sendMessage(
          customFileName ?? p.basename(path),
          type,
          currentUserId,
          mediaUrl: state.downloadUrl,
          fileName: customFileName ?? p.basename(path),
          fileSize: fileSize,
        );
        uploadSubscription.cancel();
      } else if (state is UploadFailure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('File upload failed: ${state.error}'),
            backgroundColor: AppColors.error,
          ),
        );
        uploadSubscription.cancel();
      }
    });
  }

  void _sendLocation(String currentUserId) {
    context.read<LocationBloc>().add(FetchCurrentLocationRequested());

    late StreamSubscription locationSubscription;
    locationSubscription = context.read<LocationBloc>().stream.listen((state) {
      if (state is LocationSuccess) {
        _sendMessage(
          'Location shared',
          MessageType.location,
          currentUserId,
          lat: state.latitude,
          lng: state.longitude,
        );
        locationSubscription.cancel();
      } else if (state is LocationFailure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to share location: ${state.error}'),
            backgroundColor: AppColors.error,
          ),
        );
        locationSubscription.cancel();
      }
    });
  }

  void _showAttachmentOptions(BuildContext context, String currentUserId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _AttachmentItem(
                  icon: Icons.image_rounded,
                  label: 'Gallery',
                  color: Colors.purple,
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.camera_alt_rounded,
                  label: 'Camera',
                  color: Colors.pink,
                  onTap: () {
                    Navigator.pop(context);
                    _captureImage(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.videocam_rounded,
                  label: 'Video',
                  color: Colors.orange,
                  onTap: () {
                    Navigator.pop(context);
                    _pickVideo(currentUserId);
                  },
                ),
                _AttachmentItem(
                  icon: Icons.location_on_rounded,
                  label: 'Location',
                  color: Colors.green,
                  onTap: () {
                    Navigator.pop(context);
                    _sendLocation(currentUserId);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.read<AuthBloc>().state;
    final currentUserId = authState is Authenticated ? authState.user.uid : '';

    return Scaffold(
      appBar: _buildAppBar(context),
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppColors.darkBackgroundGradient,
        ),
        child: BlocBuilder<ChatRequestBloc, ChatRequestState>(
          builder: (context, requestState) {
            final canSend = _canSendMessages(requestState);
            return Column(
              children: [
                _buildRequestBanner(requestState),

                BlocBuilder<UploadBloc, UploadState>(
                  builder: (context, state) {
                    if (state is UploadProgress) {
                      return LinearProgressIndicator(
                        value: state.progress,
                        backgroundColor: Colors.white12,
                        valueColor: const AlwaysStoppedAnimation<Color>(AppColors.secondary),
                      );
                    }
                    return const SizedBox.shrink();
                  },
                ),

                Expanded(
                  child: BlocBuilder<MessageBloc, MessageState>(
                    builder: (context, state) {
                      if (state is MessageLoading) {
                        return const Center(
                          child: CircularProgressIndicator(color: AppColors.primary),
                        );
                      }
                      if (state is MessagesLoaded) {
                        final messages = state.messages;
                        if (messages.isEmpty) {
                          return Center(
                            child: Text(
                              'Say hello to ${widget.peerName} 👋',
                              style: const TextStyle(color: AppColors.textMuted),
                            ),
                          );
                        }

                        Timer(const Duration(milliseconds: 100), () {
                          if (_scrollController.hasClients) {
                            _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
                          }
                        });

                        return ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          itemCount: messages.length,
                          itemBuilder: (context, index) {
                            final message = messages[index];
                            final isMe = message.senderId == currentUserId;
                            return _MessageBubble(
                              message: message,
                              isMe: isMe,
                              peerName: widget.peerName,
                            );
                          },
                        );
                      }
                      if (state is MessageFailure) {
                        return Center(child: Text('Error loading messages: ${state.error}'));
                      }
                      return Container();
                    },
                  ),
                ),

                _buildTypingIndicatorPanel(),

                if (canSend)
                  _buildInputBar(context, currentUserId)
                else
                  _buildDisabledInputBar(),
              ],
            );
          },
        ),
      ),
    );
  }

  bool _canSendMessages(ChatRequestState? state) {
    if (state is BetweenUsersRequestLoaded) {
      return state.request?.status == ChatRequestStatus.accepted;
    }
    return false;
  }

  Widget _buildRequestBanner(ChatRequestState? state) {
    if (state is! BetweenUsersRequestLoaded) return const SizedBox.shrink();
    final request = state.request;
    if (request == null) {
      return _banner('You need to send a chat request first.', Colors.orange);
    }
    switch (request.status) {
      case ChatRequestStatus.pending:
        return _banner('Chat request is pending. Messaging is disabled.', Colors.orange);
      case ChatRequestStatus.rejected:
        return _banner('Chat request was rejected.', AppColors.error);
      case ChatRequestStatus.accepted:
        return const SizedBox.shrink();
    }
  }

  Widget _banner(String text, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: color.withOpacity(0.15),
      child: Text(
        text,
        style: TextStyle(color: color, fontSize: 13),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildDisabledInputBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(28),
          ),
          child: const Row(
            children: [
              Icon(Icons.lock_outline, color: AppColors.textMuted, size: 18),
              SizedBox(width: 10),
              Text('Messaging unavailable', style: TextStyle(color: AppColors.textMuted)),
            ],
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      titleSpacing: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => context.pop(),
      ),
      title: BlocBuilder<PresenceBloc, PresenceState>(
        builder: (context, state) {
          String statusText = 'Offline';
          bool isOnline = false;

          if (state is PresenceLoaded) {
            statusText = 'Online';
            isOnline = true;
          } else if (state is PresenceOffline) {
            statusText = 'Last seen ${DateFormat('HH:mm').format(state.lastSeen)}';
          }

          return Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: AppColors.surfaceLight,
                backgroundImage: widget.peerImage.isNotEmpty
                    ? CachedNetworkImageProvider(widget.peerImage)
                    : null,
                child: widget.peerImage.isEmpty
                    ? const Icon(Icons.person, color: Colors.white, size: 20)
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.peerName,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      children: [
                        if (isOnline)
                          Container(
                            width: 6,
                            height: 6,
                            margin: const EdgeInsets.only(right: 6),
                            decoration: const BoxDecoration(
                              color: AppColors.success,
                              shape: BoxShape.circle,
                            ),
                          ),
                        Text(
                          statusText,
                          style: TextStyle(
                            fontSize: 11,
                            color: isOnline ? AppColors.success : AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
      actions: [
        IconButton(
          icon: Icon(CupertinoIcons.profile_circled),
          onPressed: () => context.push('${AppRoutes.profile}/${widget.peerId}'),
        ),
      ],
    );
  }

  Widget _buildTypingIndicatorPanel() {
    return BlocBuilder<TypingBloc, TypingState>(
      builder: (context, state) {
        if (state is TypingUpdated) {
          final isPeerTyping = state.typingMap[widget.peerId] ?? false;
          if (isPeerTyping) {
            return Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${widget.peerName} is typing',
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const SizedBox(
                        width: 12,
                        height: 12,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.5,
                          color: AppColors.success,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }
        }
        return const SizedBox.shrink();
      },
    );
  }

  Widget _buildInputBar(BuildContext context, String currentUserId) {
    return BlocBuilder<AudioBloc, AudioState>(
      builder: (context, audioState) {
        final isRecording = audioState is AudioRecordingInProgress;

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: const Color(0x1AFFFFFF)),
                    ),
                    child: Row(
                      children: [
                        if (!isRecording)
                          IconButton(
                            icon: const Icon(Icons.attach_file_rounded, color: AppColors.textSecondary),
                            onPressed: () => _showAttachmentOptions(context, currentUserId),
                          ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: isRecording
                                ? const _VoiceRecordingPanel()
                                : TextFormField(
                              controller: _messageController,
                              onChanged: (text) => _onTextChanged(text, currentUserId),
                              style: const TextStyle(color: Colors.white),
                              decoration: const InputDecoration(
                                hintText: 'Type a message...',
                                fillColor: Colors.transparent,
                                border: InputBorder.none,
                                enabledBorder: InputBorder.none,
                                focusedBorder: InputBorder.none,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ),
                        ),
                        if (!isRecording)
                          IconButton(
                            icon: const Icon(Icons.mic_none_rounded, color: AppColors.textSecondary),
                            onPressed: () {
                              context.read<AudioBloc>().add(StartRecordingRequested());
                            },
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () async {
                    if (isRecording) {
                      context.read<AudioBloc>().add(StopRecordingRequested());

                      late StreamSubscription audioSub;
                      audioSub = context.read<AudioBloc>().stream.listen((state) {
                        if (state is AudioRecordingSuccess) {
                          _uploadAndSendFile(
                            state.filePath,
                            MessageType.voice,
                            currentUserId,
                          );
                          audioSub.cancel();
                        }
                      });
                    } else {
                      _sendMessage(_messageController.text, MessageType.text, currentUserId);
                    }
                  },
                  child: CircleAvatar(
                    radius: 24,
                    backgroundColor: AppColors.primary,
                    child: Icon(
                      isRecording ? Icons.stop_rounded : Icons.send_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _VoiceRecordingPanel extends StatefulWidget {
  const _VoiceRecordingPanel();

  @override
  State<_VoiceRecordingPanel> createState() => _VoiceRecordingPanelState();
}

class _VoiceRecordingPanelState extends State<_VoiceRecordingPanel> {
  int _seconds = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _seconds++;
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mins = _seconds ~/ 60;
    final secs = _seconds % 60;
    final timeStr = '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';

    return Row(
      children: [
        const Icon(Icons.fiber_manual_record, color: AppColors.error, size: 14),
        const SizedBox(width: 8),
        Text('Recording... $timeStr', style: const TextStyle(color: AppColors.textPrimary)),
        const Spacer(),
        IconButton(
          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
          onPressed: () {
            context.read<AudioBloc>().add(CancelRecordingRequested());
          },
        ),
      ],
    );
  }
}

class _AttachmentItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _AttachmentItem({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: color.withOpacity(0.15),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final MessageEntity message;
  final bool isMe;
  final String peerName;

  const _MessageBubble({
    required this.message,
    required this.isMe,
    required this.peerName,
  });

  @override
  Widget build(BuildContext context) {
    final alignment = isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = isMe ? AppColors.primary : AppColors.surface;
    final textStyle = TextStyle(
      color: isMe ? Colors.white : AppColors.textPrimary,
      fontSize: 15,
    );
    final borderRadius = BorderRadius.only(
      topLeft: const Radius.circular(16),
      topRight: const Radius.circular(16),
      bottomLeft: isMe ? const Radius.circular(16) : const Radius.circular(0),
      bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(16),
    );

    return Column(
      crossAxisAlignment: alignment,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: borderRadius,
            border: Border.all(color: const Color(0x1AFFFFFF), width: 0.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMessageContent(context, textStyle),
              const SizedBox(height: 6),
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    DateFormat('HH:mm').format(message.timestamp),
                    style: const TextStyle(color: AppColors.textPrimary, fontSize: 10),
                  ),
                  if (isMe) ...[
                    const SizedBox(width: 4),
                    _buildReceiptTick(message.status),
                  ],
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMessageContent(BuildContext context, TextStyle defaultStyle) {
    switch (message.type) {
      case MessageType.text:
        return Text(message.content, style: defaultStyle);
      case MessageType.image:
        return GestureDetector(
          onTap: () {
            context.push(
              AppRoutes.imageViewer,
              extra: {'url': message.mediaUrl ?? '', 'tag': message.messageId},
            );
          },
          child: Hero(
            tag: message.messageId,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CachedNetworkImage(
                imageUrl: message.mediaUrl ?? '',
                placeholder: (context, url) => const SizedBox(
                  height: 150,
                  child: Center(
                    child: CircularProgressIndicator(color: AppColors.secondary, strokeWidth: 2),
                  ),
                ),
                errorWidget: (context, url, error) => const Icon(Icons.error, color: AppColors.error),
                fit: BoxFit.cover,
              ),
            ),
          ),
        );
      case MessageType.video:
        return GestureDetector(
          onTap: () {
            context.push(AppRoutes.videoPlayer, extra: {'url': message.mediaUrl ?? ''});
          },
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 150,
                width: 200,
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.videocam, size: 40, color: Colors.white54),
              ),
              const CircleAvatar(
                radius: 24,
                backgroundColor: Colors.black54,
                child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 32),
              ),
            ],
          ),
        );
      case MessageType.voice:
        return _VoicePlayBubble(mediaUrl: message.mediaUrl ?? '');
      case MessageType.file:
        return GestureDetector(
          onTap: () {
            context.push(
              AppRoutes.documentViewer,
              extra: {'url': message.mediaUrl ?? '', 'name': message.fileName ?? 'Document'},
            );
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.insert_drive_file_rounded, color: Colors.amber, size: 36),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      message.fileName ?? 'Document',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: defaultStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    if (message.fileSize != null)
                      Text(
                        message.fileSize!,
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 11),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      case MessageType.location:
        return GestureDetector(
          onTap: () {
            sl<LocationService>().openInGoogleMaps(message.latitude!, message.longitude!);
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  sl<LocationService>().getStaticMapUrl(message.latitude!, message.longitude!),
                  height: 120,
                  width: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      height: 120,
                      width: 200,
                      color: AppColors.surfaceLight,
                      child: Center(
                        child: Icon(
                          CupertinoIcons.map_pin_ellipse,
                          color: AppColors.textSecondary,
                          size: 40,
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  const Icon(Icons.location_on, color: Colors.redAccent, size: 16),
                  const SizedBox(width: 4),
                  Text('Shared Location', style: defaultStyle.copyWith(fontSize: 13)),
                ],
              ),
            ],
          ),
        );
    }
  }

  Widget _buildReceiptTick(MessageStatus status) {
    switch (status) {
      case MessageStatus.sent:
        return const Icon(Icons.check, size: 14, color: AppColors.textPrimary);
      case MessageStatus.delivered:
        return const Icon(Icons.done_all, size: 14, color: AppColors.textPrimary);
      case MessageStatus.seen:
        return const Icon(Icons.done_all, size: 14, color: AppColors.secondary);
    }
  }
}

class _VoicePlayBubble extends StatefulWidget {
  final String mediaUrl;
  const _VoicePlayBubble({required this.mediaUrl});

  @override
  State<_VoicePlayBubble> createState() => _VoicePlayBubbleState();
}

class _VoicePlayBubbleState extends State<_VoicePlayBubble> {
  late AudioBloc _audioBloc;

  @override
  void initState() {
    super.initState();
    _audioBloc = sl<AudioBloc>();
  }

  @override
  void dispose() {
    _audioBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: _audioBloc,
      child: BlocBuilder<AudioBloc, AudioState>(
        builder: (context, state) {
          final isPlaying = state is AudioPlaybackInProgress;
          final isPaused = state is AudioPlaybackPaused;
          final isCurrent = isPlaying || isPaused;

          Duration pos = Duration.zero;
          Duration dur = Duration.zero;

          if (state is AudioPlaybackInProgress) {
            pos = state.position;
            dur = state.duration;
          } else if (state is AudioPlaybackPaused) {
            pos = state.position;
            dur = state.duration;
          }

          final progress = dur.inMilliseconds > 0 ? pos.inMilliseconds / dur.inMilliseconds : 0.0;

          return Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: Icon(
                  isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: Colors.white,
                ),
                onPressed: () {
                  if (isPlaying) {
                    _audioBloc.add(PauseAudioRequested());
                  } else {
                    _audioBloc.add(PlayAudioRequested(widget.mediaUrl));
                  }
                },
              ),
              Expanded(
                child: SizedBox(
                  width: 120,
                  child: LinearProgressIndicator(
                    value: isCurrent ? progress : 0.0,
                    backgroundColor: Colors.white24,
                    valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                isCurrent ? _formatDuration(pos) : 'Voice',
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ],
          );
        },
      ),
    );
  }

  String _formatDuration(Duration d) {
    final mins = d.inMinutes;
    final secs = d.inSeconds % 60;
    return '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }
}